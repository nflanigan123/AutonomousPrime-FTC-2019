package org.firstinspires.ftc.robotcontroller.external.samples;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.ColorSensor;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import com.qualcomm.robotcore.robot.Robot;
import com.qualcomm.hardware.bosch.BNO055IMU;
import org.firstinspires.ftc.robotcore.external.navigation.Acceleration;
import java.util.Locale;
import com.qualcomm.robotcore.hardware.ServoImpl;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;



import java.util.ArrayList;
import java.util.List;
import  com.qualcomm.robotcore.hardware.HardwareDevice;
import org.firstinspires.ftc.teamcode.*;
import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.ServoImpl;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.hardware.bosch.JustLoggingAccelerationIntegrator;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.robotcore.external.Func;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.robotcore.external.navigation.Velocity;

@Autonomous(name="BlueOrRedAuto -CheckBeforeUseAndEdits", group ="Concept")


public class RedAutoAP extends LinearOpMode {
    boolean isTracked = false;
    private DcMotor frontLeftMotor = null;
    private  DcMotor frontRightMotor = null;
    private DcMotor backLeftMotor = null;
    private  DcMotor backRightMotor = null;
    private DcMotor elevatorMotor = null; 
     private ServoImpl hookServo = null;
     private ColorSensor colorSensor = null;
    
     
    
  BNO055IMU imu;
      // State used for updating telemetry
    Orientation angles;
    Acceleration gravity;

    

    
  

    @Override public void runOpMode() {
        frontLeftMotor = hardwareMap.get(DcMotor.class, "frontLeft");
         frontRightMotor = hardwareMap.get(DcMotor.class, "frontRight");
         backLeftMotor = hardwareMap.get(DcMotor.class, "backLeft");
         backRightMotor = hardwareMap.get(DcMotor.class, "backRight");
         elevatorMotor = hardwareMap.get(DcMotor.class, "elevatorMotor");
          hookServo = hardwareMap.get(ServoImpl.class, "hookServo");
          colorSensor = hardwareMap.get(ColorSensor.class, "colorSensor");
          
            BNO055IMU.Parameters Vuparameters = new BNO055IMU.Parameters();
        Vuparameters.angleUnit           = BNO055IMU.AngleUnit.DEGREES;
        Vuparameters.accelUnit           = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        Vuparameters.calibrationDataFile = "BNO055IMUCalibration.json"; // see the calibration sample opmode
        Vuparameters.loggingEnabled      = true;
        Vuparameters.loggingTag          = "IMU";
        Vuparameters.accelerationIntegrationAlgorithm = new JustLoggingAccelerationIntegrator();

        // Retrieve and initialize the IMU. We expect the IMU to be attached to an I2C port
        // on a Core Device Interface Module, configured to be a sensor of type "AdaFruit IMU",
        // and named "imu".
        imu = hardwareMap.get(BNO055IMU.class, "imu");
        imu.initialize(Vuparameters);
        
    
         
        waitForStart();
   frontLeftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    frontRightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    
    frontLeftMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    frontRightMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
      imu.startAccelerationIntegration(new Position(), new Velocity(), 1000);
      
        Integer leftEncoder = frontLeftMotor.getCurrentPosition();
            Integer rightEncoder = frontLeftMotor.getCurrentPosition();
          
         
//for(int i=0; i >=2; i++)
//{
 while (colorSensor.red() > 20)
        {
           frontLeftMotor.setPower(0.5);
            backLeftMotor.setPower(-0.5);
            frontRightMotor.setPower(0.5);
            backRightMotor.setPower(-0.5);
           
        }


  
          frontLeftMotor.setPower(0);
           frontRightMotor.setPower(0);
           backLeftMotor.setPower(0);
           backRightMotor.setPower(0);
           
          frontLeftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
          frontRightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
           backRightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
           backLeftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
          
          
          
             
         
          
          //go forward to grab skystone when found
          
        frontLeftMotor.setTargetPosition(600);
        backLeftMotor.setTargetPosition(600);  
        frontRightMotor.setTargetPosition(-600);
         backRightMotor.setTargetPosition(-600);
       frontLeftMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontRightMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
         backRightMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
          backLeftMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            frontLeftMotor.setPower(0.75);
           frontRightMotor.setPower(0.75);
           backLeftMotor.setPower(0.75);
           backRightMotor.setPower(0.75);
          
          
          while(frontLeftMotor.isBusy())
          {
            telemetry.addData("Leftencoder", frontLeftMotor.getCurrentPosition());
            telemetry.addData("RightEncoder", frontRightMotor.getCurrentPosition());
            telemetry.addData("BackRightEncoder", backRightMotor.getCurrentPosition());
            telemetry.addData("Back:eftEncoder", backLeftMotor.getCurrentPosition());
            telemetry.update();
          }
          
          //// go backwards to level out 
            frontLeftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
          frontRightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
           backRightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
           backLeftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
          
             
        frontLeftMotor.setTargetPosition(-1000);
        backLeftMotor.setTargetPosition(-1000);  
        frontRightMotor.setTargetPosition(1000);
         backRightMotor.setTargetPosition(1000);
         frontLeftMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontRightMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
         backRightMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
          backLeftMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            frontLeftMotor.setPower(-0.75);
           frontRightMotor.setPower(-0.75);
           backLeftMotor.setPower(-0.75);
           backRightMotor.setPower(-0.75);
             while(frontLeftMotor.isBusy())
          {
            telemetry.addData("Leftencoder", frontLeftMotor.getCurrentPosition());
            telemetry.addData("RightEncoder", frontRightMotor.getCurrentPosition());
            telemetry.addData("BackRightEncoder", backRightMotor.getCurrentPosition());
            telemetry.addData("Back:eftEncoder", backLeftMotor.getCurrentPosition());
            telemetry.update();
          }
         //strafe under the bridge
          frontLeftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    frontRightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
      backRightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
           backLeftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
          
    
       frontLeftMotor.setTargetPosition(-2500);
        backLeftMotor.setTargetPosition(2500);  
        frontRightMotor.setTargetPosition(-2500);
         backRightMotor.setTargetPosition(2500);
         frontLeftMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontRightMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
         backRightMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
          backLeftMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            frontLeftMotor.setPower(0.75);
           frontRightMotor.setPower(0.75);
           backLeftMotor.setPower(0.75);
           backRightMotor.setPower(0.75);
           while(frontLeftMotor.isBusy())
          {
            telemetry.addData("Leftencoder", frontLeftMotor.getCurrentPosition());
            telemetry.addData("RightEncoder", frontRightMotor.getCurrentPosition());
            telemetry.addData("BackRightEncoder", backRightMotor.getCurrentPosition());
            telemetry.addData("Back:eftEncoder", backLeftMotor.getCurrentPosition());
            telemetry.update();
          }
          //raise elevator
          //open hook
          hookServo.setPosition(1);
          sleep(2500);
          //lower elevator
          //strafe back
            frontLeftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    frontRightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
      backRightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
           backLeftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
          
    
          frontLeftMotor.setTargetPosition(2500);
        backLeftMotor.setTargetPosition(-2500);  
        frontRightMotor.setTargetPosition(2500);
         backRightMotor.setTargetPosition(2500);
         frontLeftMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontRightMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
         backRightMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
          backLeftMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            frontLeftMotor.setPower(-0.75);
           frontRightMotor.setPower(-0.75);
           backLeftMotor.setPower(-0.75);
           backRightMotor.setPower(-0.75);
           while(frontLeftMotor.isBusy())
          {
            telemetry.addData("Leftencoder", frontLeftMotor.getCurrentPosition());
            telemetry.addData("RightEncoder", frontRightMotor.getCurrentPosition());
            telemetry.addData("BackRightEncoder", backRightMotor.getCurrentPosition());
            telemetry.addData("Back:eftEncoder", backLeftMotor.getCurrentPosition());
            telemetry.update();
          }
          
       
}


      
    

}