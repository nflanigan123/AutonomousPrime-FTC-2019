package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoImpl;
import org.firstinspires.ftc.robotcore.external.ClassFactory;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackables;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackable;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackableDefaultListener;
import org.firstinspires.ftc.robotcore.external.matrices.OpenGLMatrix;
import org.firstinspires.ftc.robotcore.external.matrices.VectorF;
import java.util.Locale;
import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

import com.qualcomm.robotcore.hardware.CompassSensor;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;
import com.qualcomm.hardware.bosch.BNO055IMU;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.JustLoggingAccelerationIntegrator;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;  

import org.firstinspires.ftc.robotcore.external.Func;
import org.firstinspires.ftc.robotcore.external.navigation.Acceleration;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.robotcore.external.navigation.Velocity;
import org.firstinspires.ftc.robotcore.external.ClassFactory;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.matrices.OpenGLMatrix;
import org.firstinspires.ftc.robotcore.external.matrices.VectorF;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackable;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackableDefaultListener;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackables;

import java.util.ArrayList;
import java.util.List;

import static org.firstinspires.ftc.robotcore.external.navigation.AngleUnit.DEGREES;
import static org.firstinspires.ftc.robotcore.external.navigation.AxesOrder.XYZ;
import static org.firstinspires.ftc.robotcore.external.navigation.AxesOrder.YZX;
import static org.firstinspires.ftc.robotcore.external.navigation.AxesReference.EXTRINSIC;
import static org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer.CameraDirection.BACK;
import com.qualcomm.robotcore.hardware.DigitalChannel;


@TeleOp(name="A'BaseC", group="Linear Opmode")

public class APBase extends LinearOpMode {
 DigitalChannel digitalTouch;  // Hard 
    
    private OpenGLMatrix lastLocation = null;
    private VuforiaLocalizer vuforia = null;
    private boolean targetVisible = false;
    private float phoneXRotate    = 0;
    private float phoneYRotate    = 0;
    private float phoneZRotate    = 0; 
    
    private DcMotor frontLeftMotor = null;
    private  DcMotor frontRightMotor = null;
    private DcMotor backLeftMotor = null;
    private  DcMotor backRightMotor = null;
    private DcMotor elevatorMotor = null; 
 private ServoImpl hookServo = null;
    
    private DigitalChannel leftArmSwitch = null; 
     private DigitalChannel rightArmSwitch = null; 
    
    BNO055IMU imu;
    
    Orientation angles;
    @Override
    
    public void runOpMode() {
        
          
          
        telemetry.addData("Status", "Initialized");
        telemetry.update();

         frontLeftMotor = hardwareMap.get(DcMotor.class, "frontLeft");
         frontRightMotor = hardwareMap.get(DcMotor.class, "frontRight");
         backLeftMotor = hardwareMap.get(DcMotor.class, "backLeft");
         backRightMotor = hardwareMap.get(DcMotor.class, "backRight");
         elevatorMotor = hardwareMap.get(DcMotor.class, "elevatorMotor");
          hookServo = hardwareMap.get(ServoImpl.class, "hookServo");
     
         
       BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        parameters.angleUnit           = BNO055IMU.AngleUnit.DEGREES;
        parameters.accelUnit           = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        parameters.calibrationDataFile = "BNO055IMUCalibration.json"; // see the calibration sample opmode
        parameters.loggingEnabled      = true;
        parameters.loggingTag          = "IMU";
        parameters.accelerationIntegrationAlgorithm = new JustLoggingAccelerationIntegrator();

        imu = hardwareMap.get(BNO055IMU.class, "imu");
        
  
        frontLeftMotor.setDirection(DcMotor.Direction.REVERSE);
        frontRightMotor.setDirection(DcMotor.Direction.REVERSE);        
        backRightMotor.setDirection(DcMotor.Direction.REVERSE);
        backLeftMotor.setDirection(DcMotor.Direction.REVERSE);
       elevatorMotor.setDirection(DcMotor.Direction.REVERSE);
      
        
        
        //SensorManager sensorService = (SensorManager) hardwareMap.appContext.getSystemService(Context.SENSOR_SERVICE);

/*
        if (sensorService != null) {
            Sensor magField = sensorService.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
            if (magField != null) {
                // Use the magnetic field sensor here
            }
        }
        */
        
        

         composeTelemetry();
        waitForStart();
        

    
        
        while (opModeIsActive()) {
          

            telemetry.update();
            double leftPower;
            double rightPower;
            double x = deadBand(gamepad1.left_stick_x, 0.2); 
            double y = deadBand(-gamepad1.right_stick_y , 0.2);
            telemetry.addData("Status", "x: " + ((Double)x).toString());            
            telemetry.addData("Status", "y: " + ((Double)y).toString());            
            
            //double r = Math.hypot(gamepad1.left_stick_x, gamepad1.left_stick_y);
            //double robotAngle = Math.atan2(gamepad1.left_stick_y, gamepad1.left_stick_x) - (Math.PI / 4);
            double r = Math.hypot(x, y);
            
            double robotAngle = Math.atan2(y,x) - (Math.PI / 4);
                        telemetry.addData("Status", "R: " + ((Double)r).toString());            
                        telemetry.addData("Status", "RobotAngle: " + ((Double)robotAngle).toString());

            double rightX = gamepad1.right_stick_x;
            final double leftFrontPwr = r * Math.cos(robotAngle) + rightX;
            final double rightFrontPwr = r * Math.sin(robotAngle) - rightX;
            final double rightRearPwr = r * Math.sin(robotAngle) + rightX;
            final double leftRearPwr = r * Math.cos(robotAngle) - rightX;
              
            frontLeftMotor.setPower(leftFrontPwr);
            frontRightMotor.setPower(rightFrontPwr);
            backLeftMotor.setPower(leftRearPwr);
            backRightMotor.setPower(rightRearPwr);
            
            telemetry.update();
            
            if (gamepad2.dpad_up)
            {
                elevatorMotor.setPower(1);
            }
            else if (gamepad2.dpad_down)
            {
                elevatorMotor.setPower(-1);
            }
            else
            {
                elevatorMotor.setPower(0);
            }
         if (gamepad2.right_trigger == 1)
            {
                         hookServo.setPosition(0);

            }
            else if (gamepad2.left_trigger == 1)
            {
                hookServo.setPosition(0.5);
            }
           
    
              

            
    
            telemetry.update();
        }
        
    }
    void composeTelemetry() {

        // At the beginning of each telemetry update, grab a bunch of data
        // from the IMU that we will then display in separate lines.
        telemetry.addAction(new Runnable() { @Override public void run()
                {
                // Acquiring the angles is relatively expensive; we don't want
                // to do that in each of the three items that need that info, as that's
                // three times the necessary expense.
                angles   = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
                
                }
            });
            /*
            telemetry.addLine()
            .addData("heading", new Func<String>() {
                @Override public String value() {
                    return formatAngle(angles.angleUnit, angles.firstAngle);
                    }
                })
            .addData("roll", new Func<String>() {
                @Override public String value() {
                    return formatAngle(angles.angleUnit, angles.secondAngle);
                    }
                })
            .addData("pitch", new Func<String>() {
                @Override public String value() {
                    return formatAngle(angles.angleUnit, angles.thirdAngle);
                    }
            });*/ 
             }
             String formatAngle(AngleUnit angleUnit, double angle) {
       return formatDegrees(AngleUnit.DEGREES.fromUnit(angleUnit, angle));
    }

    String formatDegrees(double degrees){
        return String.format(Locale.getDefault(), "%.1f", AngleUnit.DEGREES.normalize(degrees));
    }
    double deadBand (double x, double band) 
    {
        
        if(x <= band && x >= - band)
        {
            return 0;
            
        }
        return x; 
    }
}
