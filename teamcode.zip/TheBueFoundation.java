package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import org.firstinspires.ftc.robotcore.external.ClassFactory;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackables;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackable;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackableDefaultListener;
import org.firstinspires.ftc.robotcore.external.matrices.OpenGLMatrix;
import org.firstinspires.ftc.robotcore.external.matrices.VectorF;
import java.util.Locale;
import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.CompassSensor;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;
import com.qualcomm.hardware.bosch.BNO055IMU;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.JustLoggingAccelerationIntegrator;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;  

import org.firstinspires.ftc.robotcore.external.Func;
import org.firstinspires.ftc.robotcore.external.navigation.Acceleration;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.robotcore.external.navigation.Velocity;
import org.firstinspires.ftc.robotcore.external.ClassFactory;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.matrices.OpenGLMatrix;
import org.firstinspires.ftc.robotcore.external.matrices.VectorF;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackable;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackableDefaultListener;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackables;

import java.util.ArrayList;
import java.util.List;

import static org.firstinspires.ftc.robotcore.external.navigation.AngleUnit.DEGREES;
import static org.firstinspires.ftc.robotcore.external.navigation.AxesOrder.XYZ;
import static org.firstinspires.ftc.robotcore.external.navigation.AxesOrder.YZX;
import static org.firstinspires.ftc.robotcore.external.navigation.AxesReference.EXTRINSIC;
import static org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer.CameraDirection.BACK;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

@Autonomous(name="TheRealRedAutonomous", group="Linear Opmode")



public class TheBueFoundation extends LinearOpMode  {
    
 public ElapsedTime mRunTime = new ElapsedTime(); //sets up a timer in theprogram
  boolean forward = true;


    
    private DcMotor frontLeftMotor = null;
    private  DcMotor frontRightMotor = null;
    private DcMotor backLeftMotor = null;
    private  DcMotor backRightMotor = null;
    private DcMotor elevatorMotor = null; 
    
     public void runOpMode() {
        
 frontLeftMotor = hardwareMap.get(DcMotor.class, "frontLeft");
 frontRightMotor = hardwareMap.get(DcMotor.class, "frontRight");
 backLeftMotor = hardwareMap.get(DcMotor.class, "backLeft");
 backRightMotor = hardwareMap.get(DcMotor.class, "backRight");
 elevatorMotor = hardwareMap.get(DcMotor.class, "elevatorMotor");
 
frontLeftMotor.setDirection(DcMotor.Direction.REVERSE);
frontRightMotor.setDirection(DcMotor.Direction.REVERSE);        
backRightMotor.setDirection(DcMotor.Direction.REVERSE);
backLeftMotor.setDirection(DcMotor.Direction.REVERSE);
elevatorMotor.setDirection(DcMotor.Direction.REVERSE);
        
         waitForStart();
         mRunTime.reset(); 
             frontLeftMotor.setPower(1); 
             frontRightMotor.setPower(-1);
             backLeftMotor.setPower(-1);
              backRightMotor.setPower(1);
              elevatorMotor.setPower(0);
             sleep(500);
             frontLeftMotor.setPower(1.3); 
             frontRightMotor.setPower(1.3);
             backLeftMotor.setPower(1.3);
              backRightMotor.setPower(1.3);
              elevatorMotor.setPower(0);
             sleep(1500);
             frontLeftMotor.setPower(0); 
             frontRightMotor.setPower(0);
             backLeftMotor.setPower(0);
              backRightMotor.setPower(0);
              elevatorMotor.setPower(0);
              sleep(250);
               elevatorMotor.setPower(-1);
               sleep(3000);
               frontLeftMotor.setPower(-1); 
             frontRightMotor.setPower(-1);
             backLeftMotor.setPower(-1);
              backRightMotor.setPower(-1);
              elevatorMotor.setPower(0);
              sleep(1000);
                  elevatorMotor.setPower(1);
                  sleep(3000);
                  frontLeftMotor.setPower(-1); 
             frontRightMotor.setPower(-1);
             backLeftMotor.setPower(-1);
              backRightMotor.setPower(-1);
              elevatorMotor.setPower(0);
              sleep(500);
              
                    
             
         
            
                   
                telemetry.addData("Status", "Timer:: " + mRunTime.time()); 
                telemetry.update();
                 
            
         //while active 

    }// run OpMode
    void composeTelemetry() {

        
        telemetry.addAction(new Runnable() { @Override public void run()
                {
                // Acquiring the angles is relatively expensive; we don't want
                // to do that in each of the three items that need that info, as that's
                // three times the necessary expense.
               
                }
            });
            
             

    }
    void resetArm()
    {
     
     elevatorMotor.setPower(1);
               sleep(3000);
    }
    
}// class
